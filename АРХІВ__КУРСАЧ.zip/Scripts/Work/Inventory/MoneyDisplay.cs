using UnityEngine;
using UnityEngine.UI;
using Fusion;

public class MoneyDisplay : NetworkBehaviour
{
    [Networked] public int CopperCoins { get; set; }
    [Networked] public int SilverCoins { get; set; }
    [Networked] public int GoldCoins { get; set; }

    // UI ��������
    public Text copperCoinsText;
    public Text silverCoinsText;
    public Text goldCoinsText;

    public override void Spawned()
    {
        if (!HasInputAuthority)
        {
            gameObject.SetActive(false); // �������� UI ��� ����� �������
            return;
        }

        UpdateCoinUI();
    }

    private void UpdateCoinUI()
    {
        copperCoinsText.text = CopperCoins.ToString();
        silverCoinsText.text = SilverCoins.ToString();
        goldCoinsText.text = GoldCoins.ToString();
    }

    public void AddCoins(string coinType, int amount)
    {
        if (HasInputAuthority)
        {
            RPC_AddCoins(coinType, amount);
        }
    }

    public bool DeductCoins(int copperCost, int silverCost, int goldCost)
    {
        if (HasInputAuthority)
        {
            RPC_DeductCoins(copperCost, silverCost, goldCost);
            return true;
        }
        return false;
    }

    public override void FixedUpdateNetwork()
    {
        // ����������, �� �������� ��������, � ��������� UI
        if (HasStateAuthority)
        {
            UpdateCoinUI();
        }
    }

    [Rpc(RpcSources.InputAuthority, RpcTargets.StateAuthority)]
    public void RPC_AddCoins(string coinType, int amount)
    {
        switch (coinType)
        {
            case "Copper":
                CopperCoins += amount;
                break;
            case "Silver":
                SilverCoins += amount;
                break;
            case "Gold":
                GoldCoins += amount;
                break;
            default:
                Debug.LogWarning($"�������� ��� �����: {coinType}");
                return;
        }
    }

    [Rpc(RpcSources.InputAuthority, RpcTargets.StateAuthority)]
    public void RPC_DeductCoins(int copperCost, int silverCost, int goldCost)
    {
        int totalCopper = CopperCoins + SilverCoins * 100 + GoldCoins * 10000;
        int totalCost = copperCost + silverCost * 100 + goldCost * 10000;

        if (totalCopper >= totalCost)
        {
            totalCopper -= totalCost;

            GoldCoins = totalCopper / 10000;
            totalCopper %= 10000;
            SilverCoins = totalCopper / 100;
            CopperCoins = totalCopper % 100;
        }
    }

    public int GetTotalMoney()
    {
        return CopperCoins + SilverCoins * 100 + GoldCoins * 10000;
    }
}
